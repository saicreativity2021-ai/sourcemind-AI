"""
SourceMind AI backend scaffold.
This API defines the integration shape only; it does not yet perform RAG,
PDF extraction, vector search, or LLM generation.
Run from this folder with:
    uvicorn main:app --reload
"""
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="SourceMind AI API", version="0.1.0")

# For local development only. In production, replace "*" with your frontend origin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Citation(BaseModel):
    document: str
    page: Optional[int] = None
    chunk_id: Optional[str] = None
    quote: Optional[str] = None

class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=4000)
    source_ids: List[str] = []

class ChatResponse(BaseModel):
    answer: str
    citations: List[Citation] = []
    mode: str = "not_implemented"

class SourceRecord(BaseModel):
    id: str
    filename: str
    status: str

class QuizAttempt(BaseModel):
    learner_id: str
    topic: str
    correct: bool
    question_id: str

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "SourceMind AI", "rag_ready": False}

@app.get("/api/sources", response_model=List[SourceRecord])
def list_sources():
    # TODO: Return sources from persistent database for the authenticated learner.
    return []

@app.post("/api/upload")
async def upload_source(file: UploadFile = File(...)):
    # TODO:
    # 1. Validate MIME type and file size.
    # 2. Extract text with a PDF/DOCX parser.
    # 3. Chunk text and preserve page/document metadata.
    # 4. Embed chunks and persist them in a vector index.
    # 5. Return a source record with indexing status.
    if not file.filename:
        raise HTTPException(status_code=400, detail="Filename is required.")
    return {
        "filename": file.filename,
        "status": "received_scaffold_only",
        "message": "Upload route is a scaffold. Document parsing and indexing are not implemented."
    }

@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    # TODO: Retrieve relevant chunks from source_ids, pass only retrieved context
    # to the LLM, require abstention when evidence is insufficient, and return
    # citations that map to actual document/page/chunk metadata.
    return ChatResponse(
        answer="The RAG pipeline is not connected yet. Implement retrieval and model generation before using this endpoint.",
        citations=[],
        mode="scaffold"
    )

@app.post("/api/quiz/attempt")
def save_quiz_attempt(attempt: QuizAttempt):
    # TODO: Persist the attempt and update a transparent knowledge-tracing model.
    return {
        "saved": False,
        "mode": "scaffold",
        "message": "Persistence and mastery updates are not implemented.",
        "topic": attempt.topic
    }
